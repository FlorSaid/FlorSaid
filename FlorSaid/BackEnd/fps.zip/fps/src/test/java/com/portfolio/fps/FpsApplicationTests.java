package com.portfolio.fps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FpsApplicationTests {

	@Test
	void contextLoads() {
	}

}
